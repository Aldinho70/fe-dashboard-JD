---
name: Fleet Command Telemetry
colors:
  surface: '#0b1326'
  surface-dim: '#0b1326'
  surface-bright: '#31394d'
  surface-container-lowest: '#060e20'
  surface-container-low: '#131b2e'
  surface-container: '#171f33'
  surface-container-high: '#222a3d'
  surface-container-highest: '#2d3449'
  on-surface: '#dae2fd'
  on-surface-variant: '#c2c6d6'
  inverse-surface: '#dae2fd'
  inverse-on-surface: '#283044'
  outline: '#8c909f'
  outline-variant: '#424754'
  surface-tint: '#adc6ff'
  primary: '#adc6ff'
  on-primary: '#002e6a'
  primary-container: '#4d8eff'
  on-primary-container: '#00285d'
  inverse-primary: '#005ac2'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#ca8100'
  on-tertiary-container: '#3e2400'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc6ff'
  on-primary-fixed: '#001a42'
  on-primary-fixed-variant: '#004395'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#0b1326'
  on-background: '#dae2fd'
  surface-variant: '#2d3449'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 2rem
    fontWeight: '700'
    lineHeight: 2.5rem
  headline-lg:
    fontFamily: Inter
    fontSize: 1.5rem
    fontWeight: '600'
    lineHeight: 2rem
  headline-sm:
    fontFamily: Inter
    fontSize: 1.125rem
    fontWeight: '600'
    lineHeight: 1.5rem
  title-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '600'
    lineHeight: 1.25rem
    letterSpacing: 0.05em
  body-md:
    fontFamily: Inter
    fontSize: 0.875rem
    fontWeight: '400'
    lineHeight: 1.375rem
  body-sm:
    fontFamily: Inter
    fontSize: 0.75rem
    fontWeight: '400'
    lineHeight: 1.125rem
  label-numeric-lg:
    fontFamily: JetBrains Mono
    fontSize: 1.25rem
    fontWeight: '700'
    lineHeight: 1.5rem
  label-numeric-md:
    fontFamily: JetBrains Mono
    fontSize: 0.875rem
    fontWeight: '500'
    lineHeight: 1.25rem
  label-badge:
    fontFamily: Inter
    fontSize: 0.6875rem
    fontWeight: '600'
    lineHeight: 1rem
    letterSpacing: 0.025em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-lg: 1.5rem
  margin: 1.5rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 1.75rem
---

## Brand & Style

This design system elevates enterprise telemetry, fleet logistics, and mission-critical operations into an executive command center. It bridges the structured utility and surface hierarchy of Google Material Design 3 with the refined, tactile precision of Apple Pro desktop software (macOS Sonoma / Studio Command).

### Personality & Tone
- **Mission-Critical Precision:** High signal-to-noise ratio where telemetry status, operational anomalies, and critical failures are instantly decodable without cognitive fatigue.
- **Modern Industrial Elegance:** Dark-first slate surfaces, micro-borders with translucent edge highlights, and high-density telemetry tiles replacing toy-like pastel pills with robust operational pads.
- **Real-Time Responsive:** Pulsing live-status nodes, high-contrast numeric counters, and active focus halos that convey live data feeds and high availability.

### Style Directives
- **Layering & Finish:** Deep slate backdrops (`#090D16` / `#0F172A`) paired with glass-matted containers, crisp 1px borders (`rgba(255, 255, 255, 0.08)`), and subtle ambient outer glows on focused or active telemetry pods.
- **Strict Color Semantics:** Purely functional color coding. Vibrancy is exclusively reserved for system states (Emerald for nominal telemetry, Amber for deviation/temperature warnings, Crimson for disconnects and critical hardware faults, and Cobalt Indigo for operator focus).

## Colors

The color architecture is calibrated for 24/7 control rooms and high-density operations consoles. Backgrounds avoid harsh pure blacks in favor of deep, noise-free slate and obsidian tones, reducing optical fatigue while giving maximum luminescent contrast to status indicators.

### Palette Architecture
- **Primary (`#3B82F6` / Cobalt Indigo):** Primary interactive actions, active radio/filter states, card selection halos, and breadcrumb indicators.
- **Secondary (`#10B981` / Emerald Live):** Nominal status, GPS locked, active sensors, and online connectivity.
- **Warning (`#F59E0B` / Warm Amber):** Route deviation, thermal threshold warnings, pending maintenance, and delayed telematics.
- **Critical (`#EF4444` / Crimson Alert):** Disconnected units, hardware sensor loss, SOS triggers, and telemetry dropouts.
- **Neutral Surface Palette:**
  - `Canvas / Background`: `#090D16` (Deep Space Slate)
  - `Surface Tier 1 (Panels / Dock)`: `#0F172A` (Rich Obsidian Navy)
  - `Surface Tier 2 (Interactive Tiles / Tables)`: `#1E293B` (Muted Steel Slate)
  - `Surface Tier 3 (Hover / Modals)`: `#334155` (Elevated Slate)
  - `Text Primary`: `#F8FAFC` (98% contrast white)
  - `Text Muted`: `#94A3B8` (Cool Grey)
  - `Border Subtle`: `rgba(148, 163, 184, 0.12)`
  - `Border Focus`: `rgba(59, 130, 246, 0.65)`

## Typography

The typographic engine uses **Inter** for all UI structure, headings, operational actions, and narrative labels due to its tall x-height and optical legibility at micro-scales. **JetBrains Mono** is introduced specifically for timestamps, telemetry packet readings, coordinates, device IDs, and quantitative counters to prevent layout shifting during high-frequency live data updates.

### Usage Rules
- `label-numeric-*`: Monospaced tabular figures (`tnum`) must always be enabled for live values, counts, and ISO time outputs.
- Category section tags (e.g., fleet group tabs like `NOELIE`, `DIFEYRO`) use `title-md` transformed to uppercase with `0.05em` letter tracking to maintain clarity at a glance.

## Layout & Spacing

The control center utilizes a structured 12-column responsive fluid grid with a strict 4px/8px modular base rhythm. 

### Screen Partitioning
- **Top Command App Bar:** Fixed height (56px), containing identity badge, global connection health pulse, master search, and operator utility shortcuts.
- **Launchpad Metrics Deck (Upper Zone):** Fluid multi-column modular grid housing fleet groups. On standard 1440px displays, groups occupy equal 3-column slots (or 4-column depending on active fleet groups), stacking gracefully to 2 columns on tablets and 1 column on mobile screens.
- **Data Matrix (Lower Zone):** Full-bleed responsive telemetry table with sticky header, inline quick-filters, and high-density tabular rows.

### Spacing Tokens Application
- Outer dashboard container uses `margin: 1.5rem` (`margin-mobile: 1rem` on handheld devices).
- Spacing between modular cards and deck columns uses `gutter: 1rem`.
- Padding within telemetry launchpad buttons uses `space-md` along horizontal edges and `space-sm` along vertical axes for maximum information density without crowding.

## Elevation & Depth

Visual depth is achieved through layered dark tones, subtle inner bevels, and micro-luminescent glows rather than heavy dropping shadows. This ensures crisp separation under multi-monitor configurations.

### Elevation Hierarchy
- **Level 0 (Floor Canvas):** `#090D16` baseline canvas with zero elevation.
- **Level 1 (Card & Module Enclosures):** `#0F172A` with a delicate 1px border `rgba(255, 255, 255, 0.06)` and soft ambient depth (`box-shadow: 0 4px 20px -4px rgba(0, 0, 0, 0.45)`).
- **Level 2 (Interactive Status Buttons / Launchpads):** `#1E293B` with top edge specular light (`box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.08)`) and perimeter outline `rgba(255, 255, 255, 0.04)`.
- **Level 3 (Active / Selected State):** Border color transforms to `rgba(59, 130, 246, 0.8)` accompanied by an active peripheral neon glow (`box-shadow: 0 0 16px -2px rgba(59, 130, 246, 0.35)`).
- **Floating Overlays (Flyouts & Detail Drawers):** `#1E293B` with backdrop-filter blur (16px) and high-density drop shadow (`box-shadow: 0 20px 35px -8px rgba(0, 0, 0, 0.7)`).

## Shapes

The interface embraces a refined industrial geometry with a `Soft` roundedness tier (`roundedness: 1`). This provides the sharp, dependable ergonomics of professional hardware instrumentation while preventing the toy-like sensation of deeply pill-shaped cards.

### Corner Radius Mapping
- **Modular Telemetry Buttons & Table Rows:** `rounded-md` (6px / 0.375rem) to maintain geometric rhythm in tight grids.
- **Parent Fleet Enclosures & Tables:** `rounded-lg` (8px / 0.5rem) providing containment structure.
- **Status Pills & Live Indicator Dots:** Full round (`rounded-full` / 9999px) strictly reserved for small status badges, pulse rings, and operational switch pills.

## Components

### Telemetry Launchpad Buttons (Operational Tiles)
- **Structure:** Modular touch-and-click tiles arranged inside fleet group panels.
- **Left Side:** 24px hardware icon (Satellite, Thermal Sensor, Route, Signal) encased in a soft functional tint container.
- **Center:** Clean uppercase operational status label (e.g., `ONLINE`, `DESVIADOS`, `SIN CONEXION`).
- **Right Side:** High-contrast monospaced badge displaying active count (`JetBrains Mono`). Zero values are dimmed (`#64748B`); positive alert numbers trigger amber or crimson glow.
- **Active Selection:** A 1.5px solid primary border (`#3B82F6`) with an inset gradient and accent glow.

### Fleet Enclosure Cards
- Glass-matted dark card with a crisp upper tab displaying the fleet division name (`NOELIE`, `DIFEYRO`, `FILSA`, `HRH`).
- Includes a top right inline badge summarizing active vs total units.

### Status Indicators & Pulse Nodes
- Real-time connectivity badges feature a live 6px dot with a concentric CSS ping/pulse animation for active telemetry (`#10B981`).
- Disconnected items feature a static crimson node (`#EF4444`) with hollow center indicator.

### Telemetry Data Matrix (Table)
- **Header:** Sticky, muted uppercase labels (`#64748B`, 11px, tracking-wider), bottom border `1px solid rgba(255, 255, 255, 0.08)`.
- **Row Styling:** Alternating hover highlight (`#1E293B/50`), 44px compact row height for desktop visibility.
- **Columns:**
  - `Unidad`: Bold label accompanied by small hardware ID in monospaced secondary text.
  - `Último Mensaje`: Formatted date/time with tabular numerals (`JetBrains Mono`).
  - `Conexión`: Pill chip with active pulse node and micro-label (`Online`, `Inactivo`, `Alerta`).
  - `Acciones / Ver Mapa`: Subtle icon button providing a popover mini-telemetry map route preview.

### Command Navigation & Global Bar
- Top-level dark navbar with telemetry breadcrumbs, instant filter search bar with keyboard shortcut hint (`Ctrl + K`), and dark/light system state toggle switch.